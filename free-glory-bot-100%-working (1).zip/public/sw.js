/* Minimal Service Worker for PWA Installation */
const CACHE_NAME = 'glory-bot-v6';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Network-only for everything to avoid "Always offline" issues
  event.respondWith(fetch(event.request));
});
